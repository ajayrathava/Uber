//
//  ViewController.swift
//  Uber
//
//  Created by Student on 04/02/1946 Saka.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

